Escáner de Claves de Medicamentos - Proyecto Android

Este es un proyecto Android Studio preparado para generar APK. La aplicación usa WebView con origen HTTPS local seguro (WebViewAssetLoader) para que el permiso de cámara pueda funcionar en la página integrada.

Incluye el HTML de escáner y los datos extraídos de ListaPrecios Noviembre 2026.

Para compilar:
1. Instala Android Studio (versión actual) y Android SDK 35.
2. Abre esta carpeta como proyecto (File > Open).
3. Espera la sincronización de Gradle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK de depuración se encontrará en app/build/outputs/apk/debug/app-debug.apk.

Nota: OCR Tesseract se carga desde CDN; requiere internet para descargar la librería la primera vez. La base de claves está incluida localmente.
